<?
  # Update stuff

  define('UPDATE_PATH', '%FULL PATH TO YOUR *.exe BUILD%');
  define('UPDATE_CONFIG_PATH', '%FULL PATH TO config.bin FILE%');
  define('LAST_VERSION_BOT', '10000');
?>