<?
require_once 'bt_update_stuff.php';
readfile(UPDATE_PATH);
?>