//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by HardwareDevices.rc
//
#define IDD_NETADAPTER_OPTIONS          101
#define IDD_NETADAPTER_DIALOG           102
#define IDD_NETADAPTER_PANEL            104
#define IDD_NETADAPTER_DETAILS          105
#define IDD_DISKDRIVE_DETAILS_FILESYSTEM 109
#define IDD_DISKDRIVE_DETAILS_GENERAL   111
#define IDD_GPU_DIALOG                  1077
#define IDD_DISKDRIVE_OPTIONS           1013
#define IDD_DISKDRIVE_DIALOG            1014
#define IDD_DISKDRIVE_PANEL             1016
#define IDD_DISKDRIVE_DETAILS_SMART     1017
#define IDC_GRAPH_LAYOUT                103
#define IDC_NETADAPTERS_LISTVIEW        1001
#define IDC_LINK_SPEED                  1002
#define IDC_ADAPTERNAME                 1003
#define IDC_LAYOUT                      1004
#define IDC_LINK_STATE                  1005
#define IDC_STAT_BSENT                  1006
#define IDC_STAT_BRECEIVED              1007
#define IDC_STAT_BTOTAL                 1008
#define IDC_DETAILS                     1010
#define IDC_DETAILS_LIST                1011
#define IDC_SHOW_HIDDEN_ADAPTERS        1012
#define IDC_EDIT1                       1015
#define IDC_DISKDRIVE_LISTVIEW          1017
#define IDC_DESCRIPTION                 1017
#define IDC_DISKMOUNTPATH               1018
#define IDC_TITLE                       1019
#define IDC_STAT_BREAD                  1020
#define IDC_STAT_BWRITE                 1021
#define IDC_STAT_ACTIVE                 1023
#define IDC_STAT_RESPONSETIME           1024
#define IDC_STAT_QUEUELENGTH            1025
#define IDC_DISKNAME                    1076
#define IDC_GPUNAME                     1078
#define IDC_GPU_L                       1079
#define IDC_MEMORY_L                    1080
#define IDC_SHARED_L                    1081
#define IDC_BUS_L                       1082
#define IDD_GPU_PANEL                   1083
#define IDC_CLOCK_CORE                  211
#define IDC_CLOCK_MEMORY                212
#define IDC_FAN_PERCENT                 213
#define IDC_TEMP_VALUE                  214
#define IDC_CLOCK_SHADER                215
#define IDC_VOLTAGE                     217

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        114
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1020
#define _APS_NEXT_SYMED_VALUE           106
#endif
#endif
