//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ToolStatus.rc
//
#define IDD_OPTIONS                     102
#define IDR_MAINWND_ACCEL               103
#define IDB_SEARCH_ACTIVE               104
#define IDB_SEARCH_ACTIVE_BMP           119
#define IDB_SEARCH_INACTIVE             120
#define IDB_SEARCH_INACTIVE_BMP         121
#define IDB_APPLICATION_GET_MODERN      126
#define IDB_APPLICATION_GO_MODERN       127
#define IDB_APPLICATION_MODERN          128
#define IDB_ARROW_REFRESH_MODERN        129
#define IDB_CHART_LINE_MODERN           130
#define IDB_COG_EDIT_MODERN             131
#define IDB_CROSS_MODERN                132
#define IDB_FIND_MODERN                 133
#define IDB_POWER_MODERN                134
#define IDD_CUSTOMIZE_TB                135
#define IDD_CUSTOMIZE_SB                136
#define IDI_ARROW_REFRESH               137
#define IDI_COG_EDIT                    138
#define IDI_FIND                        139
#define IDI_CHART_LINE                  140
#define IDI_TBAPPLICATION               141
#define IDI_APPLICATION_GO              142
#define IDI_CROSS                       143
#define IDI_APPLICATION_GET             144
#define IDI_LIGHTBULB_OFF               145
#define IDC_ENABLE_TOOLBAR              1001
#define IDC_ENABLE_MODERN               1002
#define IDC_ENABLE_STATUSBAR            1003
#define IDC_RESOLVEGHOSTWINDOWS         1004
#define IDC_AVAILABLE                   1005
#define IDC_ADD                         1006
#define IDC_REMOVE                      1007
#define IDC_CURRENT                     1008
#define IDC_SEARCHOPTIONS               1009
#define IDC_TEXTOPTIONS                 1010
#define IDC_MOVEUP                      1011
#define IDC_MOVEDOWN                    1012
#define IDC_THEMEOPTIONS                1013
#define IDC_RESET                       1014
#define IDC_ENABLE_AUTOHIDE_MENU        1015
#define ID_SEARCH                       40011

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        146
#define _APS_NEXT_COMMAND_VALUE         40016
#define _APS_NEXT_CONTROL_VALUE         1016
#define _APS_NEXT_SYMED_VALUE           11010
#endif
#endif
