#ifndef PHAPPREV_H
#define PHAPPREV_H

#define PHAPP_VERSION_REVISION $COMMITS$

#endif // PHAPPREV_H
