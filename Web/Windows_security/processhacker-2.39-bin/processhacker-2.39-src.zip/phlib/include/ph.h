#ifndef _PH_PH_H
#define _PH_PH_H

#pragma once

#include <phbase.h>
#include <phnative.h>
#include <phnativeinl.h>
#include <phutil.h>

#endif
