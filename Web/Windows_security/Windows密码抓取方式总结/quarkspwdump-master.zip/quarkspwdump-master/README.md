quarkspwdump
============

Dump various types of Windows credentials without injecting in any process.