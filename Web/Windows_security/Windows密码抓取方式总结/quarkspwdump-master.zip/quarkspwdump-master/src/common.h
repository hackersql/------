#pragma once

#include <windows.h>
#include <Sddl.h>
#include <Lmcons.h>
#include <stdio.h>

#define JET_VERSION 0x0501 
#include <esent.h>




